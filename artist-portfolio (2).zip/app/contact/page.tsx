"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Mail, Linkedin, ExternalLink } from "lucide-react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Outfit } from "next/font/google"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import { LayeredText } from "../about/components/layered-text"

const outfit = Outfit({ subsets: ["latin"] })

const formSchema = z.object({
  salutation: z.string(),
  name: z.string().min(2, "Name must be at least 2 characters long"),
  email: z.string().email("Invalid email address"),
  contactMethod: z.string(),
  contactInfo: z.string(),
  message: z.string().min(10, "Message must be at least 10 characters long"),
})

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      salutation: "Mr",
      name: "",
      email: "",
      contactMethod: "email",
      contactInfo: "",
      message: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    if (isSubmitting) return

    setIsSubmitting(true)
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      })

      let data
      try {
        data = await response.json()
      } catch (error) {
        console.error("Error parsing JSON:", error)
        throw new Error("Failed to parse server response")
      }

      if (response.ok) {
        toast.success(data.message || "Message sent successfully!")
        form.reset()
      } else {
        const errorMessage = data.error || "Failed to send message"
        const errorDetails = data.details ? JSON.stringify(data.details) : "No additional details"
        toast.error(`${errorMessage}. Details: ${errorDetails}`)
        console.error("Server error:", data)
      }
    } catch (error) {
      console.error("Error submitting form:", error)
      toast.error(`An unexpected error occurred: ${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mx-auto max-w-2xl"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="rounded-full bg-cyan-400/20 p-2">
              <Mail className="h-6 w-6 text-cyan-400" />
            </div>
            <LayeredText className="text-4xl font-bold tracking-tight md:text-5xl">Let's Chat</LayeredText>
          </div>
          <p className="mb-8 text-lg text-gray-400">
            Have a project in mind? I'd love to hear about it. Let's discuss how we can work together to create
            something amazing.
          </p>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="salutation"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-cyan-400">Salutation</FormLabel>
                    <RadioGroup onValueChange={field.onChange} defaultValue={field.value} className="flex gap-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Mr" id="Mr" />
                        <label htmlFor="Mr">Mr</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Ms" id="Ms" />
                        <label htmlFor="Ms">Ms</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Mrs" id="Mrs" />
                        <label htmlFor="Mrs">Mrs</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Dr" id="Dr" />
                        <label htmlFor="Dr">Dr</label>
                      </div>
                    </RadioGroup>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-cyan-400">Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your name" {...field} className="bg-zinc-900 border-cyan-400/50 text-white" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-cyan-400">Email</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="your@email.com"
                        {...field}
                        className="bg-zinc-900 border-cyan-400/50 text-white"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="contactMethod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-cyan-400">Preferred Contact Method</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-zinc-900 border-cyan-400/50 text-white">
                          <SelectValue placeholder="Select your preferred contact method" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="email">Email</SelectItem>
                        <SelectItem value="whatsapp">WhatsApp</SelectItem>
                        <SelectItem value="telegram">Telegram</SelectItem>
                        <SelectItem value="phone">Phone</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="contactInfo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-cyan-400">Contact Information</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Your contact information"
                        {...field}
                        className="bg-zinc-900 border-cyan-400/50 text-white"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-cyan-400">Message</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Your message..."
                        className="min-h-[120px] bg-zinc-900 border-cyan-400/50 text-white"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <motion.button
                type="submit"
                className="w-full rounded bg-cyan-400 py-3 text-black transition-colors hover:bg-cyan-300 disabled:opacity-50"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={isSubmitting}
              >
                {isSubmitting ? "Sending..." : "Send Message"}
              </motion.button>
            </form>
          </Form>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mt-12"
          >
            <h2 className="mb-4 text-2xl font-semibold text-cyan-400">Connect with me</h2>
            <div className="flex space-x-4">
              <a
                href="https://www.linkedin.com/in/yourprofile"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-cyan-400 hover:text-cyan-300"
              >
                <Linkedin className="mr-2 h-5 w-5" />
                LinkedIn
                <ExternalLink className="ml-1 h-4 w-4" />
              </a>
              <a
                href="https://www.behance.net/yourprofile"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-cyan-400 hover:text-cyan-300"
              >
                <ExternalLink className="mr-2 h-5 w-5" />
                Behance
                <ExternalLink className="ml-1 h-4 w-4" />
              </a>
              <a href="mailto:celestenmy23@gmail.com" className="flex items-center text-cyan-400 hover:text-cyan-300">
                <Mail className="mr-2 h-5 w-5" />
                Email
              </a>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}


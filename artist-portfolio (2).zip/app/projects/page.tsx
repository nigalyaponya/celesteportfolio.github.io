"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Crown, Compass, Palette, Code, Wand2, BrainCircuit } from "lucide-react"
import { cn } from "@/lib/utils"
import { projects } from "../data/projects"

import { Outfit } from "next/font/google"
import { LayeredText } from "../about/components/layered-text"

const outfit = Outfit({ subsets: ["latin"] })

const iconMap = {
  featured: Crown,
  ux: Compass,
  ui: Palette,
  development: Code,
  ar: Wand2,
  ai: BrainCircuit,
}

export default function ProjectsPage() {
  const [selectedCategory, setSelectedCategory] = useState("all")
  const categories = ["all", "featured", "ux", "ui", "development", "ar", "ai"]

  const filteredProjects =
    selectedCategory === "all" ? projects : projects.filter((project) => project.category === selectedCategory)

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-20">
        {/* Header */}
        <div className="mb-16 text-center">
          <LayeredText className="mb-4 text-5xl font-bold tracking-tight md:text-6xl">My Works</LayeredText>
          <motion.p
            className="mx-auto max-w-2xl text-lg text-gray-400"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            A collection of projects showcasing my journey in interaction design and user experience
          </motion.p>
        </div>

        {/* Category Filter */}
        <motion.div
          className="mb-12 flex flex-wrap justify-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`rounded-full px-6 py-2 text-sm font-medium capitalize transition-all duration-300 ${
                selectedCategory === category
                  ? "bg-cyan-400 text-black shadow-lg shadow-cyan-400/25"
                  : "bg-zinc-800 text-white hover:bg-zinc-700"
              }`}
            >
              {category}
            </button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project) => {
              const Icon = iconMap[project.category as keyof typeof iconMap] || Crown
              return (
                <motion.div
                  key={project.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.5 }}
                >
                  <Link href={`/projects/${project.id}`}>
                    <Card className="group relative overflow-hidden border-zinc-800 bg-zinc-900/50 transition-all duration-300 hover:border-cyan-400/50 hover:shadow-lg hover:shadow-cyan-400/10">
                      <CardContent className="p-0">
                        <div className="relative aspect-[4/3] overflow-hidden">
                          <img
                            src={project.image || "/placeholder.svg"}
                            alt={project.title}
                            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                        </div>
                        <div className="relative p-6">
                          <div className="mb-4 flex items-center gap-3">
                            <div className="rounded-full bg-cyan-400/20 p-2 text-cyan-400">
                              <Icon className="h-5 w-5" />
                            </div>
                            <span
                              className={cn(
                                outfit.className,
                                "text-sm font-medium uppercase tracking-wider text-cyan-400",
                              )}
                            >
                              {project.category}
                            </span>
                          </div>
                          <h3
                            className={cn(
                              outfit.className,
                              "mb-2 text-2xl font-bold tracking-tight text-white group-hover:text-cyan-400",
                            )}
                          >
                            {project.title}
                          </h3>
                          <p className="mb-4 text-sm text-gray-400">{project.description}</p>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-white">{project.role}</span>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {project.subRoles.map((subRole, index) => (
                                <span key={index} className="rounded-full bg-zinc-800 px-3 py-1 text-xs text-gray-400">
                                  {subRole}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}


import { redirect } from "next/navigation"

const projects = [
  { id: 1, title: "Digital Dreamscape" },
  { id: 2, title: "Urban Symphony" },
  { id: 3, title: "Abstract Reality" },
  // Add more projects as needed
]

export default function RandomProject() {
  const randomProject = projects[Math.floor(Math.random() * projects.length)]
  redirect(`/projects#${randomProject.id}`)
}


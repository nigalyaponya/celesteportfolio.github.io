"use client"

import { useParams } from "next/navigation"
import { motion } from "framer-motion"
import { projects } from "../../data/projects"
import { cn } from "@/lib/utils"
import { Outfit } from "next/font/google"
import Link from "next/link"
import MediaShowcase from "../../components/media-showcase"

const outfit = Outfit({ subsets: ["latin"] })

export default function ProjectPage() {
  const params = useParams()
  const project = projects.find((p) => p.id.toString() === params.id)

  if (!project) {
    return <div className="min-h-screen bg-black text-white flex items-center justify-center">Project not found</div>
  }

  const projectMedia = [
    {
      type: "image" as const,
      src: project.images[0] || "/placeholder.svg",
      alt: project.title,
      width: 1920,
      height: 1080,
    },
    // Add more media items as needed.  Consider mapping over project.images if you have multiple images.
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-20">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className={cn(outfit.className, "mb-8 text-4xl font-bold text-cyan-400 md:text-5xl")}
        >
          {project.title}
        </motion.h1>
        <div className="grid gap-12 md:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <MediaShowcase items={projectMedia} />
            <div className="mt-4 flex items-center justify-between">
              <span className="text-cyan-400">{project.category}</span>
              <span>{project.year}</span>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <h2 className="mb-4 text-2xl font-semibold text-cyan-400">Project Overview</h2>
            <p className="mb-6">{project.description}</p>
            <h3 className="mb-2 text-xl font-semibold text-cyan-400">Role</h3>
            <p className="mb-4">{project.role}</p>
            <div className="mb-6 flex flex-wrap gap-2">
              {project.subRoles.map((subRole, index) => (
                <span key={index} className="rounded-full bg-zinc-800 px-3 py-1 text-sm text-gray-400">
                  {subRole}
                </span>
              ))}
            </div>
            <h3 className="mb-2 text-xl font-semibold text-cyan-400">Challenge</h3>
            <p className="mb-6">{project.challenge}</p>
            <h3 className="mb-4 text-xl font-semibold text-cyan-400">Process</h3>
            <ul className="mb-6 space-y-4">
              {project.process.map((step, index) => (
                <li key={index}>
                  <h4 className="font-semibold text-white">{step.title}</h4>
                  <p className="text-gray-400">{step.description}</p>
                </li>
              ))}
            </ul>
            <h3 className="mb-2 text-xl font-semibold text-cyan-400">Outcome</h3>
            <p className="mb-6">{project.outcome}</p>
            {project.link && (
              <Link
                href={project.link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block rounded bg-cyan-400 px-6 py-2 text-black transition-colors hover:bg-cyan-300"
              >
                View Project
              </Link>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  )
}


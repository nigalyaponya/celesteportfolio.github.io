import "@/styles/globals.css"
import { Inter, Outfit } from "next/font/google"
import Link from "next/link"
import NeonTrail from "./components/neon-trail"
import ParticleEffect from "./components/particle-effect"
import type React from "react"

const inter = Inter({ subsets: ["latin"] })
const outfit = Outfit({ subsets: ["latin"] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} ${outfit.className} bg-black text-white`}>
        <NeonTrail />
        <ParticleEffect />
        <nav className="fixed top-0 left-0 right-0 z-50 bg-black bg-opacity-50 backdrop-blur-md">
          <div className="container mx-auto px-4 py-4">
            <ul className="flex justify-center space-x-8">
              <li>
                <Link href="/" className="text-lg hover:text-blue-400 hover:underline">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-lg hover:text-blue-400 hover:underline">
                  About
                </Link>
              </li>
              <li>
                <Link href="/projects" className="text-lg hover:text-blue-400 hover:underline">
                  Projects
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-lg hover:text-blue-400 hover:underline">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
        </nav>
        <main className="pt-16">{children}</main>
      </body>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };

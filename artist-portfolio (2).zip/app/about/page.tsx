"use client"

import { useRef } from "react"
import { motion } from "framer-motion"
import { LayeredText } from "./components/layered-text"
import FloatingWorks from "../components/floating-works"
import Scrapbook from "../components/scrapbook"
import { Outfit } from "next/font/google"

const outfit = Outfit({ subsets: ["latin"] })

export default function AboutPage() {
  const containerRef = useRef<HTMLDivElement>(null)

  return (
    <div ref={containerRef} className="min-h-screen bg-black">
      <div className="container mx-auto px-4 py-20">
        {/* Header Section */}
        <motion.section
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <LayeredText className="mb-6 text-5xl font-bold tracking-tight text-white md:text-7xl">About Me</LayeredText>
          <p className="max-w-2xl text-lg text-gray-400">
            I'm a dedicated Interaction Designer who loves to dive deep into user research. I have a keen eye for
            details and a heart for making experiences that truly matter.
          </p>
        </motion.section>

        {/* Floating Works */}
        <FloatingWorks />

        {/* Design Process Section */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20"
        >
          <LayeredText className="mb-8 text-3xl font-bold md:text-4xl text-center">My Design Process</LayeredText>
          <p className="text-center mb-12 text-lg text-gray-400 max-w-2xl mx-auto">
            My approach to design is iterative and user-centered, focusing on creating meaningful solutions through
            careful research, creative ideation, and thoughtful execution.
          </p>

          <div className="grid gap-8 md:grid-cols-3">
            {[
              {
                title: "Empathise",
                content:
                  "I start by understanding the problem and gathering insights through interviews, surveys, and user testing, gaining empathy and understanding of the case.",
                image: "/placeholder.svg?height=300&width=400",
              },
              {
                title: "Ideate",
                content:
                  "I brainstorm and sketch out ideas, creating wireframes and prototypes. I love bringing concepts to life and iterating based on feedback.",
                image: "/placeholder.svg?height=300&width=400",
              },
              {
                title: "Design!",
                content: "This step ensures that the final product is both delightful and functional.",
                image: "/placeholder.svg?height=300&width=400",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="group relative overflow-hidden rounded-lg bg-zinc-900"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <LayeredText className={`${outfit.className} mb-2 text-2xl font-semibold`}>{item.title}</LayeredText>
                  <p className="text-gray-400">{item.content}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Personal Side */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20"
        >
          <LayeredText className="mb-6 text-3xl font-bold md:text-4xl">Personal Side</LayeredText>
          <div className="space-y-8">
            <p className="text-gray-400 max-w-2xl">
              Apart from designing, I also enjoy volunteering & capturing moments. I love bringing people together.
              These activities keep me engaged with diverse communities and continuously expose me to new perspectives
              and different opportunities that come my way!
            </p>
            <Scrapbook />
          </div>
        </motion.section>
      </div>
    </div>
  )
}


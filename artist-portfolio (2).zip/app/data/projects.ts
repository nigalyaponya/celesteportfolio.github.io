export interface Project {
  id: number
  title: string
  category: string
  image: string
  role: string
  subRoles: string[]
  description: string
  sector: string
  year: string
  challenge: string
  process: {
    title: string
    description: string
  }[]
  outcome: string
  link?: string
}

export const projects: Project[] = [
  {
    id: 1,
    title: "Wander's Enigma",
    category: "featured",
    image: "/placeholder.svg?height=600&width=800",
    role: "Project Lead",
    subRoles: ["UX Design", "UI Design"],
    description:
      "An interactive, storytelling-based installation that guided visitors through various activities, including AR interactions and problem-solving.",
    sector: "Interactive Installation",
    year: "2023",
    challenge:
      "Create an engaging and educational experience that showcased the skillsets & technology learned in the course and its offerings, in an experiential and memorable way.",
    process: [
      {
        title: "Ideation and Concept Development",
        description:
          "Brainstormed ideas and developed the Alice in Wonderland theme, focusing on a light-hearted, engaging storyline.",
      },
      {
        title: "Story Mapping",
        description: "Created a detailed storyline map, outlining the user journey from entry to exit.",
      },
      {
        title: "Prototyping and Testing",
        description:
          "Developed prototypes of the interactive elements, conducting user tests to gather feedback and make necessary adjustments.",
      },
      {
        title: "Development and Implementation",
        description:
          "Coordinated with team members to build and integrate various components, including AR interactions, physical installations, and guided pathways.",
      },
      {
        title: "Execution and Feedback",
        description:
          "Managed the installation during the Open House, collecting feedback from visitors and making real-time adjustments.",
      },
    ],
    outcome:
      "Developed an Alice in Wonderland-themed installation with a guided storyline, interactive AR elements, and problem-solving activities. Received positive feedback from over 250 visitors, with an average rating of 5 out of 5 for overall experience. Increased social media following by 400 followers and attracted attention from Universal Studio Singapore.",
    link: "https://example.com/wanders-enigma",
  },
  {
    id: 2,
    title: "Video Production",
    category: "featured",
    image: "/placeholder.svg?height=600&width=800",
    role: "Director & Project Lead",
    subRoles: ["Video Production", "Content Strategy"],
    description:
      "Created a promotional video to effectively communicate with seniors and highlight the new active ageing centre's key features.",
    sector: "Video Production",
    year: "2023",
    challenge:
      "Create a promotional video that effectively communicated to seniors, making it engaging and easy to understand.",
    process: [
      {
        title: "Research and Ideation",
        description: "Conducted thorough research to gather insights and brainstormed ideas for the promotional video.",
      },
      {
        title: "Storyboarding",
        description: "Created detailed storyboards to plan the video's structure and content.",
      },
      {
        title: "Prototyping and Testing",
        description:
          "Developed prototypes of the video content, conducting user tests with the target audience to gather feedback.",
      },
      {
        title: "Production",
        description: "Filmed and edited the video, incorporating feedback from testing.",
      },
      {
        title: "Evaluation and Iteration",
        description: "Collected feedback after the video launch and made necessary adjustments.",
      },
    ],
    outcome:
      "Developed a clear and engaging video focusing on the centre's key features, ensuring the content was accessible and appealing to the senior audience. The project won an award for its clarity, feasibility, and detail-oriented design.",
    link: "https://example.com/video-production",
  },
  {
    id: 3,
    title: "Wayfinding System",
    category: "ux",
    image: "/placeholder.svg?height=600&width=800",
    role: "Lead Designer",
    subRoles: ["Project Planning", "User Research"],
    description:
      "Created a user-friendly and intuitive navigation system for dementia patients through thematic murals.",
    sector: "Wayfinding",
    year: "2023",
    challenge:
      "Design a wayfinding system that aided dementia patients in navigating the space, making it intuitive and easily recognizable.",
    process: [
      {
        title: "Research and Ideation",
        description: "Conducted thorough research to gather insights and brainstormed ideas for the murals.",
      },
      {
        title: "Sketching and Prototyping",
        description: "Created sketches and prototypes of the mural designs.",
      },
      {
        title: "Testing and Feedback",
        description:
          "Conducted usability tests with dementia patients and caregivers to gather feedback and make necessary adjustments.",
      },
      {
        title: "Implementation",
        description: "Painted the murals at the centre, ensuring they were placed strategically for maximum impact.",
      },
      {
        title: "Evaluation and Iteration",
        description: "Collected feedback after implementation and made necessary adjustments.",
      },
    ],
    outcome:
      "Developed thematic murals that were visually engaging and easily recognizable, helping dementia patients navigate the space with ease. The project won 2nd place for its clarity, feasibility, and detail-oriented design.",
    link: "https://example.com/wayfinding-system",
  },
  {
    id: 4,
    title: "Synapse",
    category: "development",
    image: "/placeholder.svg?height=600&width=800",
    role: "Web Designer",
    subRoles: ["UX Research", "UI Design", "Front-End Development"],
    description: "Created an intuitive and engaging user interface that simplified event planning.",
    sector: "Website Design & Development",
    year: "2023",
    challenge:
      "Develop a user-friendly platform that caters to both novice and experienced event planners, addressing the complexities and stress of organising events.",
    process: [
      {
        title: "Research and Analysis",
        description: "Conducted extensive research to gather user insights and understand the competitive landscape.",
      },
      {
        title: "Concept Ideation",
        description: "Brainstormed ideas and planned the design system, creating wireframes and mockups.",
      },
      {
        title: "Design System and Style Guide",
        description: "Developed a consistent design system and style guide to ensure uniformity across the platform.",
      },
      {
        title: "Development",
        description:
          "Built the website using HTML and CSS for structure and styling, incorporating animations and interactive elements to enhance user experience.",
      },
      {
        title: "Testing and Iteration",
        description: "Conducted usability tests and made iterative improvements based on user feedback.",
      },
    ],
    outcome:
      "Developed a responsive web design that includes features such as a user-friendly dashboard, automated scheduling, vendor management, and real-time updates. The website saw a significant increase in user engagement due to its intuitive design and efficient workflow.",
    link: "https://example.com/synapse",
  },
  {
    id: 5,
    title: "Giordano Redesigned",
    category: "ui",
    image: "/placeholder.svg?height=600&width=800",
    role: "UI/UX Designer",
    subRoles: ["Business Analysis", "UX Mapping"],
    description:
      "Redesigned the Giordano website to create a seamless and engaging online shopping experience that mirrored the in-store experience.",
    sector: "Retail",
    year: "2023",
    challenge: "Address the disparity between online and in-store experiences and improve Giordano's online exposure.",
    process: [
      {
        title: "Research and Analysis",
        description: "Conducted thorough business and user research to gather insights and identify key issues.",
      },
      {
        title: "Concept Ideation",
        description:
          "Developed ideas for improving the user experience, focusing on aligning online and in-store experiences.",
      },
      {
        title: "Wireframing and Prototyping",
        description: "Created wireframes and prototypes to visualize the proposed solutions.",
      },
      {
        title: "Development and Testing",
        description:
          "Built the redesigned website, integrating new features and conducting usability tests to gather feedback.",
      },
      {
        title: "Iteration and Refinement",
        description:
          "Made iterative improvements based on user feedback to ensure the final design met user and business goals.",
      },
    ],
    outcome:
      "Redesigned the website, added features like AR try-on and a chatbot, and ensured alignment with Giordano's brand vision. Saw a significant increase in user engagement and online sales.",
    link: "https://example.com/giordano-redesigned",
  },
  {
    id: 6,
    title: "Nandos App Redesigned",
    category: "ui",
    image: "/placeholder.svg?height=600&width=800",
    role: "UX Designer",
    subRoles: ["App Design", "Design System"],
    description: "Redesigned the Nandos app to improve user experience and engagement.",
    sector: "UI Design",
    year: "2024",
    challenge:
      "Improve the user experience and functionality of the Nandos app to increase customer engagement and satisfaction.",
    process: [
      {
        title: "User Research",
        description: "Conducted user interviews and surveys to understand pain points and preferences.",
      },
      {
        title: "Competitive Analysis",
        description: "Analyzed competitor apps to identify best practices and opportunities for improvement.",
      },
      {
        title: "Design System Creation",
        description: "Developed a comprehensive design system to ensure consistency across the app.",
      },
      {
        title: "Prototyping",
        description: "Created interactive prototypes to test and refine the new design.",
      },
      {
        title: "User Testing",
        description: "Conducted usability tests with target users to gather feedback and make necessary adjustments.",
      },
    ],
    outcome:
      "Created a more intuitive and visually appealing app design that improved user satisfaction and increased engagement with Nandos' digital offerings.",
    link: "https://www.behance.net/gallery/198512147/Nandos-User-Experience-Redesign",
  },
]


"use client"

import { motion } from "framer-motion"
import { useRef } from "react"
import { useScroll } from "framer-motion"

export default function FloatingWorks() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  })

  const works = [
    {
      id: 1,
      image: "/placeholder.svg?height=200&width=300",
      x: "20%",
      y: "10%",
      rotate: -5,
    },
    {
      id: 2,
      image: "/placeholder.svg?height=200&width=300",
      x: "60%",
      y: "30%",
      rotate: 5,
    },
    {
      id: 3,
      image: "/placeholder.svg?height=200&width=300",
      x: "30%",
      y: "50%",
      rotate: -8,
    },
  ]

  return (
    <div ref={containerRef} className="relative h-[600px]">
      {works.map((work) => (
        <motion.div
          key={work.id}
          className="absolute"
          style={{
            left: work.x,
            top: work.y,
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          whileHover={{ scale: 1.1 }}
        >
          <motion.div
            className="relative overflow-hidden rounded-lg shadow-xl"
            animate={{
              y: [0, -10, 0],
              rotate: [work.rotate, work.rotate + 2, work.rotate],
              scale: [1, 1.02, 1],
            }}
            transition={{
              duration: 4,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          >
            <img
              src={work.image || "/placeholder.svg"}
              alt={`Work ${work.id}`}
              className="h-auto w-48 object-cover md:w-64"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 transition-opacity duration-300 hover:opacity-100" />
          </motion.div>
        </motion.div>
      ))}
    </div>
  )
}


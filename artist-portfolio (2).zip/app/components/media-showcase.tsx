"use client"

import { useState } from "react"
import Image from "next/image"

type MediaItem = {
  type: "image" | "video"
  src: string
  alt?: string
  width: number
  height: number
}

type MediaShowcaseProps = {
  items: MediaItem[]
}

export default function MediaShowcase({ items }: MediaShowcaseProps) {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextItem = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % items.length)
  }

  const prevItem = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + items.length) % items.length)
  }

  const currentItem = items[currentIndex]

  return (
    <div className="relative w-full max-w-3xl mx-auto">
      <div className="aspect-w-16 aspect-h-9 bg-gray-200 rounded-lg overflow-hidden">
        {currentItem.type === "image" ? (
          <Image
            src={currentItem.src || "/placeholder.svg"}
            alt={currentItem.alt || ""}
            width={currentItem.width}
            height={currentItem.height}
            className="object-cover"
          />
        ) : (
          <video src={currentItem.src} controls className="w-full h-full object-cover">
            Your browser does not support the video tag.
          </video>
        )}
      </div>
      <button
        onClick={prevItem}
        className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-2 rounded-full"
      >
        &#8592;
      </button>
      <button
        onClick={nextItem}
        className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-2 rounded-full"
      >
        &#8594;
      </button>
    </div>
  )
}


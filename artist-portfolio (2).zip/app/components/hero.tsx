"use client"

import { useRef, useEffect, useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { TypeAnimation } from "react-type-animation"
import { ArrowRight } from "lucide-react"
import { LayeredText } from "../about/components/layered-text"
import SoftwareCarousel from "./software-carousel"

export default function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = 0.5
    }
  }, [])

  return (
    <div className="relative h-screen w-full overflow-hidden">
      <video
        ref={videoRef}
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 h-full w-full object-cover opacity-30"
      >
        <source src="/your-video-reel.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      <div className="relative z-10 flex h-full flex-col items-start justify-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="mb-6 w-full text-left">
          <TypeAnimation
            sequence={["Celeste Ng", () => setShowContent(true)]}
            wrapper="div"
            cursor={false}
            repeat={0}
            speed={50}
            className="text-6xl font-bold tracking-tighter sm:text-7xl lg:text-8xl"
          >
            {(text) => (
              <LayeredText>
                <span className="text-white">{text}</span>
              </LayeredText>
            )}
          </TypeAnimation>
        </div>

        {showContent && (
          <>
            <motion.div
              className="flex flex-col items-start space-y-4 w-full"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <p className="text-lg text-gray-400 sm:text-xl">Interaction Designer | User Researcher</p>
              <p className="max-w-[600px] text-base text-gray-500 sm:text-lg">
                With 3 years of experience in learning, competitions, & industry projects, I love that what I do can
                make people happy and at ease, and creating memorable experiences.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="w-full mt-8"
            >
              <SoftwareCarousel />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="mt-8"
            >
              <Link href="/projects/random">
                <button className="group relative px-8 py-3 text-white overflow-hidden">
                  <span className="relative z-10 flex items-center gap-2">
                    Explore a Project!
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </span>
                  <div className="absolute inset-0 rounded-full bg-black/50 backdrop-blur-sm" />
                  <div className="absolute inset-0 rounded-full overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-cyan-600 opacity-50 blur transition-all group-hover:opacity-75" />
                    <svg className="absolute inset-0 h-full w-full" preserveAspectRatio="none">
                      <rect
                        className="animate-flow-around"
                        width="100%"
                        height="100%"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                    </svg>
                  </div>
                </button>
              </Link>
            </motion.div>
          </>
        )}
      </div>
    </div>
  )
}


"use client"

import { useRef } from "react"
import { motion, useAnimationFrame, useMotionValue } from "framer-motion"

const SOFTWARE_LIST = [
  { name: "Adobe XD", icon: "/media/icons/xd.svg" },
  { name: "Figma", icon: "/media/icons/figma.svg" },
  { name: "Blender", icon: "/media/icons/blender.svg" },
  { name: "TouchDesigner", icon: "/media/icons/touchdesigner.svg" },
  { name: "CapCut", icon: "/media/icons/capcut.svg" },
  { name: "Canva", icon: "/media/icons/canva.svg" },
  { name: "Illustrator", icon: "/media/icons/illustrator.svg" },
  { name: "Photoshop", icon: "/media/icons/photoshop.svg" },
  { name: "VS Code", icon: "/media/icons/vscode.svg" },
]

export default function SoftwareCarousel() {
  const baseVelocity = -1
  const baseX = useMotionValue(0)
  const containerRef = useRef<HTMLDivElement>(null)

  useAnimationFrame((time) => {
    const x = baseX.get()
    if (!containerRef.current) return

    const containerWidth = containerRef.current.offsetWidth
    const contentWidth = containerRef.current.scrollWidth / 2 // Divide by 2 because we duplicate the list

    if (x <= -contentWidth) {
      baseX.set(0)
    } else {
      baseX.set(x + baseVelocity)
    }
  })

  return (
    <div className="relative w-full overflow-hidden">
      <motion.div ref={containerRef} className="flex gap-8 py-4" style={{ x: baseX }}>
        {[...SOFTWARE_LIST, ...SOFTWARE_LIST].map((software, index) => (
          <div key={`${software.name}-${index}`} className="w-10 h-10 flex-shrink-0">
            <img
              src={software.icon || "/placeholder.svg"}
              alt={software.name}
              className="w-full h-full object-contain filter brightness-75 hover:brightness-100 transition-all"
            />
          </div>
        ))}
      </motion.div>
    </div>
  )
}


"use client"

import { useEffect, useRef, useState } from "react"

export default function NeonTrail() {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isDragging, setIsDragging] = useState(false)

  useEffect(() => {
    if (!containerRef.current) return

    const container = containerRef.current
    const numParticles = 30
    const particles: { element: HTMLDivElement; x: number; y: number; scale: number }[] = []

    // Create particles
    for (let i = 0; i < numParticles; i++) {
      const particle = document.createElement("div")
      particle.classList.add("particle")
      container.appendChild(particle)
      particles.push({ element: particle, x: 0, y: 0, scale: 1 })
    }

    let mouseX = window.innerWidth / 2
    let mouseY = window.innerHeight / 2

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX
      mouseY = e.clientY
    }

    const handleTouchMove = (e: TouchEvent) => {
      mouseX = e.touches[0].clientX
      mouseY = e.touches[0].clientY
    }

    const handleMouseDown = () => setIsDragging(true)
    const handleMouseUp = () => setIsDragging(false)
    const handleTouchStart = () => setIsDragging(true)
    const handleTouchEnd = () => setIsDragging(false)

    document.addEventListener("mousemove", handleMouseMove)
    document.addEventListener("touchmove", handleTouchMove)
    document.addEventListener("mousedown", handleMouseDown)
    document.addEventListener("mouseup", handleMouseUp)
    document.addEventListener("touchstart", handleTouchStart)
    document.addEventListener("touchend", handleTouchEnd)

    function animate() {
      let prevX = mouseX
      let prevY = mouseY

      particles.forEach((particle, index) => {
        if (isDragging || index === 0) {
          const dx = prevX - particle.x
          const dy = prevY - particle.y

          particle.x += dx * 0.15
          particle.y += dy * 0.15

          const distance = Math.sqrt(dx * dx + dy * dy)
          particle.scale = Math.max(0.3, 1 - distance / 100)

          particle.element.style.transform = `translate(${particle.x}px, ${particle.y}px) scale(${particle.scale})`
          particle.element.style.opacity = `${1 - index / numParticles}`

          prevX = particle.x
          prevY = particle.y
        }
      })

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("touchmove", handleTouchMove)
      document.removeEventListener("mousedown", handleMouseDown)
      document.removeEventListener("mouseup", handleMouseUp)
      document.removeEventListener("touchstart", handleTouchStart)
      document.removeEventListener("touchend", handleTouchEnd)
      particles.forEach((particle) => particle.element.remove())
    }
  }, [isDragging])

  return (
    <div ref={containerRef} className="fixed inset-0 pointer-events-none z-50">
      <style jsx global>{`
        .particle {
          position: fixed;
          width: 20px;
          height: 20px;
          background-color: #00FFFF;
          border-radius: 50%;
          transform: translate(-50%, -50%);
          filter: blur(5px);
          box-shadow: 0 0 10px #00FFFF, 0 0 20px #00FFFF, 0 0 30px #00FFFF, 0 0 40px #00FFFF;
        }
      `}</style>
    </div>
  )
}


"use client"

import { useRef, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useInView } from "framer-motion"
import Link from "next/link"
import { ChevronRight, ChevronLeft } from "lucide-react"
import { LayeredText } from "../about/components/layered-text"
import { projects } from "../data/projects"

export default function FeaturedProjects() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })
  const [currentIndex, setCurrentIndex] = useState(0)

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % projects.length)
  }

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + projects.length) % projects.length)
  }

  const getProjectIndex = (offset: number) => {
    return (currentIndex + offset + projects.length) % projects.length
  }

  return (
    <section className="relative py-32">
      <div ref={ref} className="container mx-auto px-4">
        <LayeredText className="mb-16 text-center text-3xl font-bold tracking-tighter text-cyan-400 sm:text-4xl">
          Projects
        </LayeredText>
        <div className="relative mx-auto max-w-6xl">
          <div className="relative h-[500px]">
            <div className="absolute inset-0 flex items-center justify-center">
              <AnimatePresence initial={false}>
                {[-1, 0, 1].map((offset) => {
                  const project = projects[getProjectIndex(offset)]
                  return (
                    <motion.div
                      key={`${project.id}-${offset}`}
                      className="absolute w-[300px]"
                      initial={{ opacity: 0, x: offset * 320 }}
                      animate={{
                        opacity: 1,
                        x: offset * 320,
                        scale: offset === 0 ? 1.1 : 0.8,
                        zIndex: offset === 0 ? 10 : 0,
                      }}
                      exit={{ opacity: 0, x: offset * -320 }}
                      transition={{
                        type: "spring",
                        stiffness: 300,
                        damping: 30,
                      }}
                    >
                      <Link href={`/projects/${project.id}`}>
                        <div
                          className={`group relative aspect-[4/3] overflow-hidden rounded-lg ${
                            offset === 0 ? "shadow-lg shadow-cyan-500/50" : ""
                          }`}
                        >
                          <img
                            src={project.image || "/placeholder.svg"}
                            alt={project.title}
                            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                          <div className="absolute inset-0 p-6 flex flex-col justify-end opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                            <h3 className="text-xl font-semibold text-white mb-2">{project.title}</h3>
                            <p className="text-sm text-gray-300">{project.description}</p>
                          </div>
                          <div className="absolute top-4 right-4 bg-cyan-400 text-black px-2 py-1 text-xs font-semibold rounded">
                            {project.category}
                          </div>
                        </div>
                      </Link>
                    </motion.div>
                  )
                })}
              </AnimatePresence>
            </div>
          </div>
          <button
            onClick={prev}
            className="absolute -left-12 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-2 text-white backdrop-blur-sm transition-colors hover:bg-cyan-500/20"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            onClick={next}
            className="absolute -right-12 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-2 text-white backdrop-blur-sm transition-colors hover:bg-cyan-500/20"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
      </div>
    </section>
  )
}


import Link from "next/link"
import { Github, Linkedin, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="border-t border-zinc-800 bg-black py-12">
      <div className="container mx-auto px-4">
        <div className="mb-8 flex justify-center space-x-6">
          <a
            href="https://github.com/yourusername"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-cyan-400"
          >
            <Github className="h-6 w-6" />
            <span className="sr-only">GitHub</span>
          </a>
          <a
            href="https://linkedin.com/in/yourusername"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-cyan-400"
          >
            <Linkedin className="h-6 w-6" />
            <span className="sr-only">LinkedIn</span>
          </a>
          <a
            href="https://twitter.com/yourusername"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-cyan-400"
          >
            <Twitter className="h-6 w-6" />
            <span className="sr-only">Twitter</span>
          </a>
        </div>
        <div className="mb-8 flex justify-center space-x-8">
          <Link
            href="/about"
            className="text-lg text-white underline decoration-2 underline-offset-4 transition-colors hover:text-cyan-400"
          >
            About Me
          </Link>
          <Link
            href="/projects"
            className="text-lg text-white underline decoration-2 underline-offset-4 transition-colors hover:text-cyan-400"
          >
            Projects
          </Link>
          <Link
            href="/contact"
            className="text-lg text-white underline decoration-2 underline-offset-4 transition-colors hover:text-cyan-400"
          >
            Contact
          </Link>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <p className="text-sm text-gray-400">© {new Date().getFullYear()} Celeste Ng. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="text-gray-400 transition-colors hover:text-cyan-400">
              Instagram
            </a>
            <a href="#" className="text-gray-400 transition-colors hover:text-cyan-400">
              Twitter
            </a>
            <a href="#" className="text-gray-400 transition-colors hover:text-cyan-400">
              LinkedIn
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}

